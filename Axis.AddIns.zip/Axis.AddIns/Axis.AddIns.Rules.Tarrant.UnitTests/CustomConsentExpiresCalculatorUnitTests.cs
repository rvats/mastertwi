﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FluentAssertions;

namespace Axis.AddIns.Rules.Tarrant.UnitTests
{
    [TestClass]
    public class CustomConsentExpiresCalculatorUnitTests
    {
        [TestMethod]
        public void Can_Tarrant_HipaaConsentExpires()
        {
            // Arrange
            var subject = new CustomConsentExpiresCalculator();

            // Act
            var actual = subject.HipaaConsentExpires(new DateTime(2017, 2, 24, 18, 9, 00));


            // Assert
            actual.Should().Be(new DateTime(2017, 12, 26, 23, 59, 59, 999));
        }
    }
}
