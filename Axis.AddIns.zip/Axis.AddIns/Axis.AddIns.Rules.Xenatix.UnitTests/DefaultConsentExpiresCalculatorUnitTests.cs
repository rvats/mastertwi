﻿using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Axis.AddIns.Rules.Xenatix.UnitTests
{
    [TestClass]
    public class DefaultConsentExpiresCalculatorUnitTests
    {
        [TestMethod]
        public void Can_Xenatix_EhrPhotoIdExpires()
        {
            // Arrange
            var subject = new DefaultConsentExpiresCalculator();

            // Act
            var actual = subject.EhrPhotoIdExpires(new DateTime(2018, 2, 24, 18, 9, 00));

            // Assert
            actual.Should().BeSameDateAs(new DateTime(2028, 2, 24));
        }

        [TestMethod]
        public void Can_Xenatic_GeneralReleaseExpires_NotDischarged()
        {
            // Arrange
            var subject = new DefaultConsentExpiresCalculator();

            // Act
            var actual = subject.GeneralReleaseExpires(new DateTime(2018, 2, 24, 18, 9, 00));

            // Assert
            actual.Should().BeSameDateAs(new DateTime(2118, 2, 24));
        }

        [TestMethod]
        public void Can_Xenatic_GeneralReleaseExpires_Discharged()
        {
            // Arrange
            var subject = new DefaultConsentExpiresCalculator();

            // Act
            var actual = subject.GeneralReleaseExpires(new DateTime(2018, 2, 24, 18, 9, 00), new DateTime(2018, 4, 2, 18, 9, 00));

            // Assert
            actual.Should().BeSameDateAs(new DateTime(2118, 2, 24));
        }

        [TestMethod]
        public void Can_Xenatix_ConsumerRightsAcknowledgementExpires()
        {
            // Arrange
            var subject = new DefaultConsentExpiresCalculator();

            // Act
            var actual = subject.ConsumerRightsAcknowledgementExpires(new DateTime(2018, 2, 24, 18, 9, 00));

            // Assert
            actual.Should().Be(new DateTime(2018, 12, 31, 23, 59, 59, 999));
        }

        [TestMethod]
        public void Can_Xenatix_HipaaConsentExpires()
        {
            // Arrange
            var subject = new DefaultConsentExpiresCalculator();

            // Act
            var actual = subject.HipaaConsentExpires(new DateTime(2018, 2, 24, 18, 9, 00));

            // Assert
            actual.Should().Be(new DateTime(2018, 12, 31, 23, 59, 59, 999));
        }

        [TestMethod]
        public void Can_Xenatix_ProtectedHealthInformationAmmendmentExpires_NoDischarged()
        {
            // Arrange
            var subject = new DefaultConsentExpiresCalculator();

            // Act
            var actual = subject.ProtectedHealthInformationAmmendmentExpires(new DateTime(2018, 2, 24, 18, 9, 00));

            // Assert
            actual.Should().Be(new DateTime(2018, 12, 31, 23, 59, 59, 999));
        }

        [TestMethod]
        public void Can_Xenatix_RightsAbuseNeglectComplaintProcedureTelephoneExpires_Discharged()
        {
            // Arrange
            var subject = new DefaultConsentExpiresCalculator();

            // Act
            var actual = subject.RightsAbuseNeglectComplaintProcedureTelephoneExpires(new DateTime(2018, 2, 24, 18, 9, 00), new DateTime(2018, 2, 27));

            // Assert
            actual.Should().BeSameDateAs(new DateTime(2018, 2, 27));
        }        
    }
}
