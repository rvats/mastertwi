﻿namespace Axis.AddIns.Rules.Contracts
{
    public interface ICalculatorMetadata
    {
        string Version { get; }

        string CustomerName { get; }

        string CustomerCode { get; }
    }
}
