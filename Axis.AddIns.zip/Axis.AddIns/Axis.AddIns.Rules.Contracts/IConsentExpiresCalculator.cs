﻿using System;

namespace Axis.AddIns.Rules.Contracts
{
    public interface IConsentExpiresCalculator
    {
        DateTime ConsumerRightsAcknowledgementExpires(DateTime consentSigned, DateTime? discharged = null);

        DateTime EhrPhotoIdExpires(DateTime consentSigned, DateTime? discharged = null);

        DateTime GeneralReleaseExpires(DateTime consentSigned, DateTime? discharged = null);

        [Obsolete("Consider removing since not found in documentation of PBI 9585")]
        DateTime HipaaConsentExpires(DateTime consentSigned, DateTime? discharged = null);

        DateTime ProtectedHealthInformationAmmendmentExpires(DateTime consentSigned, DateTime? discharged = null);

        DateTime RightsAbuseNeglectComplaintProcedureTelephoneExpires(DateTime consentSigned, DateTime? discharged = null);
    }
}
