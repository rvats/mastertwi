﻿using Axis.AddIns.Rules.Contracts;
using Axis.AddIns.Rules.Xenatix;
using System;
using System.ComponentModel.Composition;

namespace Axis.AddIns.Rules.Tarrant
{
    [Export("ConsentExpiresCalculator", typeof(IConsentExpiresCalculator))]
    [ExportMetadata("Version", "1.2.1")]
    [ExportMetadata("CustomerName", "Tarrant County Customer")]
    [ExportMetadata("CustomerCode", "TXTCC")]
    public class CustomConsentExpiresCalculator : DefaultConsentExpiresCalculator, IConsentExpiresCalculator
    {
        public new DateTime HipaaConsentExpires(DateTime consentSigned)
        {
            return base.HipaaConsentExpires(consentSigned).AddDays(-5);
        }
    }
}
