﻿using Axis.AddIns.Rules.Contracts;
using System;
using System.ComponentModel.Composition;

namespace Axis.AddIns.Rules.Xenatix
{
    [Export("ConsentExpiresCalculator", typeof(IConsentExpiresCalculator))]
    [ExportMetadata("Version", "1.2.1")]
    [ExportMetadata("CustomerName", "Xenatix Axis")]
    [ExportMetadata("CustomerCode", "XEN")]
    public class DefaultConsentExpiresCalculator : IConsentExpiresCalculator
    {
        public DateTime ConsumerRightsAcknowledgementExpires(DateTime consentSigned, DateTime? discharged = null)
        {
            return EndOfYearOrDischarge(consentSigned, discharged);
        }

        public DateTime EhrPhotoIdExpires(DateTime consentSigned, DateTime? discharged = null)
        {
            return consentSigned.AddYears(10);
        }

        public DateTime GeneralReleaseExpires(DateTime consentSigned, DateTime? discharged = null)
        {
            return consentSigned.AddYears(100);
        }

        public DateTime HipaaConsentExpires(DateTime consentSigned, DateTime? discharged = null)
        {
            return EndOfYearOrDischarge(consentSigned, discharged);
        }

        public DateTime ProtectedHealthInformationAmmendmentExpires(DateTime consentSigned, DateTime? discharged = null)
        {
            return EndOfYearOrDischarge(consentSigned, discharged);
        }

        public DateTime RightsAbuseNeglectComplaintProcedureTelephoneExpires(DateTime consentSigned, DateTime? discharged = null)
        {
            return EndOfYearOrDischarge(consentSigned, discharged);
        }

        protected DateTime EndOfYear(int year)
        {
            return new DateTime(year: year,
                        month: 12,
                        day: 31,
                        hour: 23,
                        minute: 59,
                        second: 59);
        }

        private DateTime EndOfYearOrDischarge(DateTime consentSigned, DateTime? discharged)
        {
            if (discharged.HasValue)
            {
                return discharged.Value;
            }
            else
            {
                return this.EndOfYear(consentSigned.Year);
            }
        }
    }
}
