﻿using Axis.AddIns.Rules.Contracts;
using Axis.AddIns.Rules.Xenatix;
using System;
using System.ComponentModel.Composition;

namespace Axis.AddIns.Rules.Harris
{
    [Export("CustomConsentRules", typeof(IConsentExpiresCalculator))]
    [ExportMetadata("Version", "1.2.1")]
    [ExportMetadata("CustomerName", "Harris County Customer")]
    [ExportMetadata("CustomerCode", "HARCC")]
    public class CustomConsentExpiresCalculator : DefaultConsentExpiresCalculator, IConsentExpiresCalculator
    {
        public new DateTime HipaaConsentExpires(DateTime consentSigned, DateTime? discharged = null)
        {
            return base.HipaaConsentExpires(consentSigned).AddMonths(-1);
        }
    }
}
