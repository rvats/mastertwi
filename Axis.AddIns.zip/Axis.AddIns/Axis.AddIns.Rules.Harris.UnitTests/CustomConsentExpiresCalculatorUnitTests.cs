﻿using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Axis.AddIns.Rules.Harris.UnitTests
{
    [TestClass]
    public class CustomConsentExpiresCalculatorUnitTests
    {
        [TestMethod]
        public void Can_Harris_HipaaConsentExpires()
        {
            // Arrange
            var subject = new CustomConsentExpiresCalculator();

            // Act
            var actual = subject.HipaaConsentExpires(new DateTime(2017, 2, 24, 18, 9, 00));

            // Assert
            actual.Should().Be(new DateTime(2017, 11, 30, 23, 59, 59, 999));
        }
    }
}
