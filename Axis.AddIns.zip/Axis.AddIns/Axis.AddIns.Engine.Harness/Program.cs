﻿using Axis.AddIns.Rules.Contracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Configuration;
using System.Linq;

namespace Axis.AddIns.Engine.Harness
{
    class Program
    {
        private CompositionContainer _container;

        [ImportMany("ConsentExpiresCalculator")]
        private IEnumerable<Lazy<IConsentExpiresCalculator, ICalculatorMetadata>> lazyConsentExpiresCalc;

        private Program()
        {
            var catalog = new AggregateCatalog();
            catalog.Catalogs.Add(new AssemblyCatalog(typeof(Program).Assembly));

            string directoryName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            var dc = new DirectoryCatalog(directoryName + @"\AddIns");
            System.Diagnostics.Debug.WriteLine(dc.FullPath);

            catalog.Catalogs.Add(dc);

            this._container = new CompositionContainer(catalog);

            try
            {
                this._container.ComposeParts(this);
            }
            catch (CompositionException compositionException)
            {
                Console.WriteLine(compositionException.ToString());
            }
        }

        static void Main(string[] args)
        {
            var custCode = ConfigurationManager.AppSettings["CustomizationCode"];

            Program p = new Program();


            Lazy<IConsentExpiresCalculator, ICalculatorMetadata> obj = null;
            ICalculatorMetadata metaData = null;

            try
            {                
                obj = p.lazyConsentExpiresCalc.Single(e => e.Metadata.CustomerCode == custCode);
                metaData = obj.Metadata;
            }
            catch (InvalidOperationException imvoEx)
            {
                // Found zero OR more than one custom rules
             
                //TODO: Log
                
                throw;
            }
            catch (Exception ex)
            {
                //TODO: Log

                throw;
            }

            IConsentExpiresCalculator calc = obj.Value;

            Console.WriteLine("AddIns Extensions");
            Console.WriteLine("Customer Code: {0}", metaData.CustomerCode);
            Console.WriteLine("Customer Name: {0}", metaData.CustomerName);
            Console.WriteLine();

            //Console.WriteLine("Greeting:");
            //Console.WriteLine(calc.GetGreeting());
            //Console.WriteLine();

            Console.WriteLine("Calculated Expiration:");
            Console.WriteLine("A consent signed now would expire at: {0}", calc.HipaaConsentExpires(DateTime.Now));
            Console.WriteLine();

            Console.ReadKey();
        }
    }

    public interface INameMetadata
    {
        string CustomerCode { get; }
    }
}
