var npmExample = require('npm-example3');

npmExample.printMsg();