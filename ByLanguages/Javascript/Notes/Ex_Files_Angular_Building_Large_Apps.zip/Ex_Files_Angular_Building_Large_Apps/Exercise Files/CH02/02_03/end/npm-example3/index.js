exports.printMsg = () => {
  console.log('This is a message from the example NPM package');
}