import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-single',
  templateUrl: './contact-single.component.html',
  styleUrls: ['./contact-single.component.css']
})
export class ContactSingleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
