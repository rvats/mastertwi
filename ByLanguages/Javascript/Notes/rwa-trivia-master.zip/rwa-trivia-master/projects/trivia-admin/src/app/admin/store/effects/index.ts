import { AdminEffects } from './admin.effects';

export * from './admin.effects';

export const effects = [
    AdminEffects
];
