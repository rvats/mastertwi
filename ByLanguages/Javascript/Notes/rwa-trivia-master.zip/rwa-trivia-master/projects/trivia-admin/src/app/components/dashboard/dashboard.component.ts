import { Component, Input, OnInit, OnDestroy } from '@angular/core';


@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: []
})
export class DashboardComponent implements OnInit, OnDestroy {


  constructor() {

  }


  ngOnInit() {

  }

  ngOnDestroy() {

  }


}


