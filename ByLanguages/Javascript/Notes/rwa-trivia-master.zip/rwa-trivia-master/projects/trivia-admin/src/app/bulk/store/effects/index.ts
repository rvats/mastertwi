import { BulkEffects } from './bulk.effects';

export * from './bulk.effects';

export const effects = [
    BulkEffects
];
