// tslint:disable-next-line:eofline
export * from './game-filter.pipe';