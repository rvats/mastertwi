

export class Invitation {
    id: string;
    created_uid: string;
    email: string;
    status: string;
}
