import { LoginComponent } from './login/login.component';

export {
    LoginComponent
};

export default [
    LoginComponent
];