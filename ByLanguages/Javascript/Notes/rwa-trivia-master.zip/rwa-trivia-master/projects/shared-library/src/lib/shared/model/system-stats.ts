export class SystemStatsBase {
    active_games?: number;
    game_played?: number;
}
export class SystemStats extends SystemStatsBase {
    total_users?: number;
    total_questions?: number;
}
