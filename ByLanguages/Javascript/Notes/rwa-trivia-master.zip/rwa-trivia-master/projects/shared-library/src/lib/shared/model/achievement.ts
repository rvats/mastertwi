export class Achievement {
    id?: string;
    achievements?: string[];
}

