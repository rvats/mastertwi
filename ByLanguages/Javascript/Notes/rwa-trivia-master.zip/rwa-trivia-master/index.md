# Firestore index lists

* gameOver Ascending playerId_0 Ascending gameOverAt Descending

    `Fields`
    - gameOver Ascending
    - playerId_0 Ascending
    - gameOverAt Descending

    
* gameOver Ascending playerId_0 Ascending turnAt Descending
    
    `Fields`
    - gameOver Ascending
    - playerId_0 Ascending
    - turnAt Descending

    
* gameOver Ascending winnerPlayerId Ascending
    
    `Fields`
    - gameOver Ascending
    - winnerPlayerId Ascending

    
* gameOver Ascending playerId_1 Ascending gameOverAt Descending
    
    `Fields`
    - gameOver Ascending
    - playerId_1 Ascending
    - gameOverAt Descending

    
* gameOver Ascending playerId_1 Ascending turnAt Descending
    
    `Fields`
    - gameOver Ascending
    - playerId_1 Ascending
    - turnAt Descending

    
* GameStatus Ascending turnAt Descending
    
    `Fields`
    - GameStatus Ascending
    - turnAt Descending
